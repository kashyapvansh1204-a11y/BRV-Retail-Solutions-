package com.brv.retailsolutions;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.Color;
import android.net.Uri;
import android.provider.Settings;
import android.view.*;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    LinearLayout root;
    ArrayList<Uri> photos = new ArrayList<>();
    final int PICK_PHOTO = 101;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);
        findViewById(R.id.dataButton).setOnClickListener(v -> showData());
        findViewById(R.id.photoButton).setOnClickListener(v -> choosePhoto());
    }

    void showData() {
        final EditText input = new EditText(this);
        input.setHint("Excel data / row details");
        input.setMinLines(5);
        new AlertDialog.Builder(this).setTitle("Excel Data")
            .setView(input)
            .setPositiveButton("SAVE", (d,w) -> Toast.makeText(this,"Data saved",Toast.LENGTH_SHORT).show())
            .setNegativeButton("CANCEL",null).show();
    }

    void choosePhoto() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.setType("image/*"); i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,true);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        startActivityForResult(i,PICK_PHOTO);
    }

    @Override protected void onActivityResult(int r,int c,Intent d) {
        super.onActivityResult(r,c,d);
        if(r==PICK_PHOTO && c==RESULT_OK && d!=null) {
            if(d.getClipData()!=null) for(int x=0;x<d.getClipData().getItemCount();x++) photos.add(d.getClipData().getItemAt(x).getUri());
            else if(d.getData()!=null) photos.add(d.getData());
            Toast.makeText(this, photos.size()+" photo(s) selected",Toast.LENGTH_SHORT).show();
        }
    }
}
