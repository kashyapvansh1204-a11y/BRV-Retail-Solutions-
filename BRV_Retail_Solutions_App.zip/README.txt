BRV Retail Solutions Android App
- Launcher/home-screen app.
- Opening screen shows BRV Retail Solutions.
- DATA button for entering Excel-style data.
- PHOTOS button opens phone photo picker and supports multiple photos.
- Build with Android Studio/Gradle.
