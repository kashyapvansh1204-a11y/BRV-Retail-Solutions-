BRV Retail Solutions Android App

This is an Android Studio project.

Build/install:
1. Install Android Studio on a PC.
2. Open this project folder.
3. Let Gradle sync.
4. Build > Build APK(s).
5. Copy the generated app-debug.apk to your phone and tap it to install.
6. If Android blocks installation, allow "Install unknown apps" for the app/file manager you used.

Current version:
- Opening screen: BRV Retail Solutions
- DATA section
- PHOTOS: view/upload picker
- EXCEL DATA: 500 rows x 500 columns concept
