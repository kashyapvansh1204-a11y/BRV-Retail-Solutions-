package com.brv.retailsolutions;

import android.app.*;import android.os.*;import android.content.*;import android.graphics.Color;import android.net.Uri;import android.provider.Settings;import android.view.*;import android.widget.*;import java.util.*;

public class MainActivity extends Activity {
    LinearLayout root; ArrayList<Uri> photos=new ArrayList<>();
    @Override public void onCreate(Bundle b){super.onCreate(b);setContentView(R.layout.activity_main);
        findViewById(R.id.dataBtn).setOnClickListener(v->showData());
        findViewById(R.id.photoBtn).setOnClickListener(v->showPhotos());
        findViewById(R.id.excelBtn).setOnClickListener(v->showExcel());
    }
    void showData(){ final EditText e=new EditText(this); e.setHint("Enter your data"); e.setMinLines(5); new AlertDialog.Builder(this).setTitle("Data").setView(e).setPositiveButton("Save",(d,w)->Toast.makeText(this,"Data saved on this screen",Toast.LENGTH_SHORT).show()).setNegativeButton("Cancel",null).show(); }
    void showPhotos(){
        LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(25,10,25,10);
        Button add=new Button(this); add.setText("Upload Photo"); box.addView(add);
        TextView count=new TextView(this); count.setText("Photos added: "+photos.size()); box.addView(count);
        add.setOnClickListener(v->{Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("image/*");i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,true);i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,10);});
        new AlertDialog.Builder(this).setTitle("Photos").setView(box).setPositiveButton("Close",null).show();
    }
    void showExcel(){
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(20,10,20,10);
        TextView t=new TextView(this);t.setText("Excel-style data area\n\nRows: 500\nColumns: 500\n\nYou can later connect/import your Excel file here.");t.setTextSize(16);box.addView(t);
        new AlertDialog.Builder(this).setTitle("Excel Data").setView(box).setPositiveButton("OK",null).show();
    }
    @Override protected void onActivityResult(int r,int c,Intent d){super.onActivityResult(r,c,d);if(r==10&&c==RESULT_OK&&d!=null){if(d.getClipData()!=null){for(int x=0;x<d.getClipData().getItemCount();x++)photos.add(d.getClipData().getItemAt(x).getUri());}else if(d.getData()!=null)photos.add(d.getData());Toast.makeText(this,photos.size()+" photo(s) selected",Toast.LENGTH_SHORT).show();}}
}
